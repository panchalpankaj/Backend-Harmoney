const DATABASE_NAME = "event"

module.exports = { DATABASE_NAME }